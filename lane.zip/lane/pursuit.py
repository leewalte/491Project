#!/usr/bin/env python

import numpy as np
import rospy
import time
import argparse
from copy import deepcopy
import copy as copy_module
from geometry_msgs.msg import Pose, PoseArray, PoseStamped, Twist
from nav_msgs.msg import Odometry,OccupancyGrid
from std_msgs.msg import Header
from tf.transformations import quaternion_from_euler
import tf2_ros, tf2_geometry_msgs
import matplotlib.pyplot as plt

class pushFoward():
    def __init__(self):
        self.speed = 0.1
        self.x = 0
        self.y = 0
        self.pubVel = rospy.Publisher('/cmd_vel', Twist,queue_size=1)
        rospy.Subscriber("/points", PoseArray, self.points)
        #rospy.sleep(1)
    
    def points(self,msg):
        self.x = msg.poses[0].position.x
        self.y = msg.poses[0].position.y

        if self.x == 0 and self.y == 0:
            self.speed = 0

        #x, y = self.x, self.y
        print(self.x, self.y)
        k = 2*self.y/(self.x**2 + self.y**2)
        if abs(k) > 5:
            k = 5*k/abs(k)

        move = Twist()
        move.linear.x = self.speed
        move.angular.z = (k*self.speed)
        self.pubVel.publish(move)
        #self.angSpeed(self.arcCalc())
        #rospy.sleep(5)

    def arcCalc(self):
        x, y = self.x, self.y
        print(x, y)
        k = 2*y/(x**2 + y**2)
        if abs(k) > 5:
            k = 5*k/abs(k)
        return k

    def angSpeed(self,k):
        move = Twist()
        move.linear.x = self.speed
        move.angular.z = (k*self.speed)
        self.pubVel.publish(move)
        #rospy.sleep(0.1)

if __name__=='__main__':
    rospy.init_node('ex2')

    push = pushFoward()

    rospy.spin()